var request = require('supertest');

app = require('../app');


var assert = require('chai').assert;


describe('homepage', function(){
    it('Shows to do list', function(done){
      request(app).get("/todo")
      .expect(200)
      .expect(/My to do list/, done)
      })
})      


describe("To do list form", function(){
     it("List the to do task after entering the todo-list", function(done){
        request(app).post("/todo")
           .send({id: "Eat"})
           .expect(302)
           .expect('Location', "/todo", function(){
             request(app).get("/todo")
               .expect(200)
               .expect(/My to do list/, done)
           })
     
     })
})     
